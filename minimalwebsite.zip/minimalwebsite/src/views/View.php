<?php

/**
 * A class for preparing and rendering pages for the minimal web site.
 * The basic usage of this class consists of calling one of the "makeXXXPage" methods, then
 * calling the "render" method.
 * @author Alexandre Niveau and Bruno Zanuttini, Université de Caen Normandie, France
 */
class View {

    /** The title for this page (prepared by the "makeXXXPage" methods). */
    private $title;

    /** The URL to the stylesheet for this page. */
    private $styleSheetURL;

    /** The main content for this page (prepared by the "makeXXXPage" methods). */
    private $content;

    // Generic methods ========================================================================

    /**
     * Builds a new instance.
     * @param $router The router handling URLs
     */
    public function __construct (Router $router) {
        $this->router = $router;
        $this->title = null;
        $this->styleSheetURL = $router->getURL("minimalsite.css");
        $this->content = null;
    }

    /**
     * Renders the prepared page. If no page has been prepared, then makeUnexpectedErrorPage() is called first.
     */
    public function render () {
        if ($this->title===null || $this->content===null) {
            $this->makeUnexpectedErrorPage(new Exception ("Tried to render a view with null title or content"));
        }
        // Now $this->title and $this->content are nonnull
        $title = $this->title;
        $styleSheetURL = $this->styleSheetURL;
        $content = $this->content;
        $menu = $this->getMenu();
        include("template.php");
    }

    // Methods for preparing specific pages ========================================================

    /**
     * Prepares a page welcoming the user to the web site.
     */
    public function makeWelcomePage () {
        $this->title = "Site d'information sur les lettres";
        $this->content = file_get_contents("fragments/welcome.html",true);
    }

    /**
     * Prepares a page showing information about a given letter.
     * @param $char A character
     */
    public function makeLetterPage (Character $char) {
        $this->title = "Information sur la lettre '".$char->getLetter()."'";
        $ord = $char->getRank();
        $ordAsString = ($ord==1 ? "1re" : $ord."e");
        $this->content = "<p>La lettre '".$char->getLetter()."' est la ".$ordAsString." lettre de l'alphabet.</p>";
    }

    /**
     * Prepares a page showing information about a given list of letters.
     * @param $chars An array of characters (as instances of class Character)
     * @param $title The title for this page
     */
    public function makeLetterListPage (array $chars, $title) {
        $this->title = $title;
        $this->content = "<table>\n";
        $this->content.= "<tr><th>Lettre</th><th>Rang</th></tr>\n";
        foreach ($chars as $char) {
            $this->content.= "<tr><td>".$char->getLetter()."</td><td>".$char->getRank()."</td></tr>\n";
        }
        $this->content.= "</table>\n";
    }

    /**
     * Prepares a page explaining that the required URL does not exist.
     * @param $url The unknown url
     */
    public function makeUnknownURLPage ($url) {
        $this->title="Erreur";
        $this->content=file_get_contents("fragments/unknownURL.html",true);
    }

    /**
     * Prepares a page explaining that an unexpected exception or error occurred.
     * @param $e The (unexpected) exception or error raised
     */
    public function makeUnexpectedErrorPage ($e) {
        $this->title="Erreur: ".$e;
        $this->content=file_get_contents("fragments/unexpectedError.html",true);
    }

    // Helper method ========================================================

    /**
     * Returns a menu for all pages.
     * @return An associative array $url => $text
     */
    protected function getMenu () {
        return array(
            $this->router->getWelcomeURL() => "accueil",
            $this->router->getInformationURL('a') => "information sur la lettre 'a'",
            $this->router->getInformationURL('b') => "information sur la lettre 'b'",
            $this->router->getAlphabetURL() => "l'alphabet français"
        );
    }

}

?>
