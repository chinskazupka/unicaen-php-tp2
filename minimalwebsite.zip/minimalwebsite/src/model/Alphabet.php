<?php

require_once("Character.php");

/**
 * A utility class for representing the Latin alphabet.
 * @author Alexandre Niveau and Bruno Zanuttini, Université de Caen Normandie, France
 */
class Alphabet {

    /**
     * Returns a list containing all letters in the alphabet, in order and in lowercase.
     * @returns A list containing all letters in the alphabet, as instances of Character.
     */
    public static function getAllLetters () {
        $res = array();
        for ($code=ord('a'); $code<=ord('z'); $code++) {
            $res[] = new Character (chr($code));
        }
        return $res;
    }

    /**
     * Decides whether a given character is in the latin (lowercase) alphabet.
     * @param $char A character
     * @return true is the given character is a lowercase character in the Latin alphabet,
     * false otherwise
     */
    public static function isInAlphabet ($char) {
        // Implementation note: takes advantage of the fact that characters in the Latin alphabet
        // have contiguous ASCII codes
        return $char>='a' && $char<='z';
    }

}

?>
