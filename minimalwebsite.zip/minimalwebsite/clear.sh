#!/bin/sh

find . -name "*~" -exec rm -i {} \;
rm -rf doc/html

