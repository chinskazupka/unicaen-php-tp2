#!/bin/sh

php test/testcharacter.php
php test/testalphabet.php

