#!/bin/sh

doxygen doc/Doxyfile

